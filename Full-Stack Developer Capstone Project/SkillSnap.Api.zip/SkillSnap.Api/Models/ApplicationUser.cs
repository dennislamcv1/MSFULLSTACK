using Microsoft.AspNetCore.Identity;

namespace SkillSnap.Api.Models;

public class ApplicationUser : IdentityUser
{
    // You can add custom properties here if needed
    // e.g., public string DisplayName { get; set; }
}
