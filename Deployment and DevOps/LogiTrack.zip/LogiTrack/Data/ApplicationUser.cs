using Microsoft.AspNetCore.Identity;

namespace LogiTrack.Data
{
    public class ApplicationUser : IdentityUser
    {
        // You can add custom properties here later
    }
}
